# This project is to model how company is structured.
# We have a root node (only one) and several children nodes,each one with its own children as well. It's a tree-based structure.
# Implement two Rest APIs that will serve the two basic operations:
1) Get all children nodes of a given node (the given node can be anyone in the tree structure).
2) Change the parent node of a given node (the given node can be anyone in the tree structure).

Each node should have the following info:
1) node identification
2) who is the parent node
3) who is the root node
4) the height of the node. In the above example,height(root) = 0 and height(a) == 1.

Can only have docker and docker-compose in server.
Three docker files are created: Dockerfile, Makefile, node.conf

## Technology introduction
# I use Java, SpringBoot and Jersey.

# Application to demonstrate various parts of a service oriented RESTfull application.

## Technology Stack
Component         | Technology
---               | ---
Backend (REST)    | [SpringBoot] (Java)
Security          | Token Based (Spring Security)
REST Documentation| [Swagger UI / Springfox]
REST Spec         | [Open API Standard](https://www.openapis.org/) 
In Memory DB      | H2 
Persistence       | JPA (Using Spring Data)
Server Build Tools| Maven(Java)


## Prerequisites
Ensure you have this installed before proceeding the code running
- Java 1.8
- Maven 3.3.9+ or Gradle 3.3+
- Node 6.0 or above,  
- npm 5 or above,   
- Angular-cli 1.6.3

## About
This is an RESTfull implementation of an order processing app based on database schema.
The goal of the project is to 
- Highlight techniques of making and securing a REST full app using [SpringBoot]
- How to consume an RESTfull service and make an HTML5 based Single Page App using Angular

## Features of the Project
* Backend
  * Token Based Security (using Spring security)
  * API documentation and Live Try-out links with Swagger 
  * In Memory DB with H2 
  * Using JPA and JDBC template to talk to relational database
  * How to request and respond for paginated data

## Spring security
Security is **enabled** by default.
When security is enabled, none of the REST API will be accessesble directly.

In order to access these secured API you must first obtain a token. Tokens can be obtained by passing a valid userid/password
userid and password are stored in database.
To get a token call `POST /session` API with a valid userid and password.

### Build Backend (SpringBoot Java)
# Maven Build : Navigate to the root folder where pom.xml is present
mvn clean install
