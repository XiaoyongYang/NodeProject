package com.app.model.node;

import io.swagger.annotations.*;
import lombok.*;
import java.util.*;
import com.app.model.response.*;

/**
 If the response contains a list(array) or a single item, then it will have 'items' field
 **/
@Data
@EqualsAndHashCode(callSuper=false)
public class NodeResponse extends OperationResponse {
  @ApiModelProperty(required = true, value = "")
  private List<Node> items;

    public void setItems(List<Node> items) {
        this.items = items;
    }

    public List<Node> getItems() {
        return items;
    }
}
