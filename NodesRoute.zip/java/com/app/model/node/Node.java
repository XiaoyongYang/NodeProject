package com.app.model.node;

import lombok.*;
import java.util.*;
import javax.persistence.*;
import io.swagger.annotations.ApiModelProperty;

@Data
@Entity
@Table(name = "nodes")
public class Node  {

    @Id
    //@GeneratedValue(strategy = GenerationType.AUTO)
    private Long  id;
    private Long  parentNodeId;
    private Long  rootNodeId;
    private Long  height;

    public void setId(Long  id) {
        this.id = id;
    }

    public Long  getId() {
        return id;
    }

    public void setParentNodeId(Long   parentNodeId) {
        this.parentNodeId = parentNodeId;
    }

    public Long  getParentNodeId() {
        return parentNodeId;
    }
    
    public void setRootNodeId(Long   rootNodeId) {
        this.rootNodeId = rootNodeId;
    }

    public Long  getRootNodeId() {
        return rootNodeId;
    }
    
    public void setHeight(Long  height) {
        this.height = height;
    }

    public Long  getHeight() {
        return height;
    }
}
