package com.app.model.response;

import io.swagger.annotations.*;
import lombok.*;

/**
 This is the common structure for the response
 **/
@Data //for getters and setters
public class OperationResponse {
  public enum ResponseStatusEnum {SUCCESS, ERROR, WARNING, NO_ACCESS};
  @ApiModelProperty(required = true)
  private ResponseStatusEnum  operationStatus;
  private String  operationMessage;

    public void setOperationStatus(ResponseStatusEnum  operationStatus) {
        this.operationStatus = operationStatus;
    }

    public ResponseStatusEnum getOperationStatus() {
        return operationStatus;
    }

    public void setOperationMessage(String  operationMessage) {
        this.operationMessage = operationMessage;
    }

    public String getOperationMessage() {
        return operationMessage;
    }
}
