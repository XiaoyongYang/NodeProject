package com.app.model.response;

public class NodeNotFoundException extends RuntimeException {

    NodeNotFoundException(Long id) {
        super("Could not find node " + id);
    }
}
