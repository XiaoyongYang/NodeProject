package com.app.repo;

import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.*;
import com.app.model.node.*;

public interface NodeRepo extends JpaRepository<Node, Long> {
    public List<Node> findAll();
    public List<Node> findById(Long id);
    public List<Node> findByParentNodeId(Long id);
    Node update(Node node);
    boolean exists( Long id);
}

