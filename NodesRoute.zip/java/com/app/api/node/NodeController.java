package com.app.api.node;

import io.swagger.annotations.*;
import javax.servlet.http.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.data.domain.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import com.app.api.*;
import com.app.model.node.*;
import com.app.repo.*;
import com.app.model.response.*;
import static com.app.model.response.OperationResponse.*;

@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@Transactional
@RequestMapping(value = "/api", produces = MediaType.APPLICATION_JSON_VALUE)
@Api(tags = {"Node"})
public class NodeController {

  @Autowired private JdbcTemplate jdbcTemplate;
  @Autowired private NodeRepo nodeRepo;
  @Autowired private Node node;
  @Autowired private Node childNode;

    NodeController(NodeRepository repository) {
        this.repository = repository;
    }

  @ApiOperation(value = "Get all children nodes of a given node", response = NodesResponse.class)
  @RequestMapping(value = "/nodes", method = RequestMethod.GET)
  public NodeResponse getChildrenNodes(
    @ApiParam(value = "between 0 to 100000000") @RequestParam(value = "currentNodeId"  ,  defaultValue="0"   ,  required = false) Long currentNodeId,
  ) {
      NodeResponse resp = new NodeResponse();
      if (currentNodeId != null) {
          if(nodeRepo.exists(currentNodeId)) {
              node.setParentNodeId(currentNodeId);
              List<Node> childrenNodes = new ArrayList<Node>();
              List<Node> nodeList = new ArrayList<Node>();
              List<Node> nodes = nodeRepo.findAll(org.springframework.data.domain.Example.of(node));
              do {
                  nodeList = nodes;
                  nodes = null;
                  for( Node node: nodeList){
                      childrenNodes.add(node);
                      childNode.setParentNodeId(node.getId());
                      nodes += nodeRepo.findAll(org.springframework.data.domain.Example.of(childNode));
                  }

              } while (nodes != null);
              resp.setItems(childrenNodes);
              resp.setOperationStatus(ResponseStatusEnum.SUCCESS);
              resp.setOperationMessage("SUCCESS: Get all children nodes of a given node");
          } else {
              resp.setOperationStatus(ResponseStatusEnum.ERROR);
              resp.setOperationMessage("Unable to get all children nodes of a given node: given-node is not existed");
          }

      } else {
              resp.setOperationStatus(ResponseStatusEnum.ERROR);
              resp.setOperationMessage("Unable to get all children nodes of a given node: given-node-id is null");
      }
      return resp;
  }

  @ApiOperation(value = "Change the parent node of a given node", response = NodesResponse.class)
  @RequestMapping(value = "/nodes", method = RequestMethod.GET)
  public OperationResponse changeParentNode(
    @ApiParam(value = "between 0 to 10000000000") @RequestParam(value = "currentNodeId"  ,  defaultValue="0"   ,  required = false) Long currentNodeId,
	@ApiParam(value = "between 0 to 10000000000") @RequestParam(value = "newParentNodeId"  ,  defaultValue="0"   ,  required = false) Long newParentNodeId,
  ) {
      OperationResponse resp = new NodeResponse();

      if (currentNodeId != null && newParentNodeId != null) {
          if(nodeRepo.exists(currentNodeId) && nodeRepo.exists(newParentNodeId)) {
              nodeRepo.findById(currentNodeId)
                  .map(node -> {
                      node.setParentNodeId(newParentNodeId);
                      nodeRepo.save(node);
                  });
              resp.setOperationStatus(ResponseStatusEnum.SUCCESS);
              resp.setOperationMessage("SUCCESS: Change the parent node of a given node");
          } else {
              resp.setOperationStatus(ResponseStatusEnum.ERROR);
              resp.setOperationMessage("Unable to change the parent node of a given node: given-node or change-parent-node is not existed");
          }
      } else {
              resp.setOperationStatus(ResponseStatusEnum.ERROR);
              resp.setOperationMessage("Unable to change the parent node of a given node: given-node-id or change-parent-node-id is null");
      }
      return resp;
  }

}
